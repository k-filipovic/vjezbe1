import Projectile as p

s=p.Projectile(15, 45, 1, 1, 1)
s.graf()
