import math

class Projectile:
    def __init__(self, v, k, m, x, y):
        self.v=v
        self.k=math.radians(k)
        self.m=m
        self.x=x
        self.y=y
        self.x_eul = [self.x]   #pravim listu u koju ce se poslije spremati x
        self.y_eul = [self.y]
        self.x_r4= [self.x]
        self.y_r4= [self.y]
        self.vx=v*math.cos(self.k)
        self.vy=v*math.sin(self.k)

    def __Euler(self, dt):       
        b=1
        g=9.81
        self.ax= -b*self.vx/self.m
        self.ay=(-b*self.vy-self.m*g)/self.m
        self.vx=self.vx + self.ax*dt
        self.vy=self.vy + self.ay*dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.x_eul.append(self.x)
        self.y_eul.append(self.y)

    def __R4(self, dt):
    import numpy as np
    dt=0.001 
    v1 = np.sqrt(vx**2 + vy**2)     #k1
    ax1 = -(k/m) * v1 * vx
    ay1 = -g - (k/m) * v1 * vy
    
    vx2=vx+ax1*dt/2   #k2
    vy2=vy+ay1*dt/2
    v2 = np.sqrt(vx2**2 + vy2**2)
    ax2 = -(k/m) * v2 * vx2
    ay2 = -g - (k/m) * v2 * vy2
    
    vx3 = vx + ax2 * dt/2       #k3
    vy3 = vy + ay2 * dt/2
    v3 = np.sqrt(vx3**2 + vy3**2)
    ax3 = -(k/m) * v3 * vx3
    ay3 = -g - (k/m) * v3 * vy3
    
    vx4 = vx + ax3 * dt     #k4
    vy4 = vy + ay3 * dt
    v4 = np.sqrt(vx4**2 + vy4**2)
    ax4 = -(k/m) * v4 * vx4
    ay4 = -g - (k/m) * v4 * vy4
    
    #brzina prema r4
    vx = vx + (dt/6)*(ax1 + 2*ax2 + 2*ax3 + ax4)
    vy = vy + (dt/6)*(ay1 + 2*ay2 + 2*ay3 + ay4)
    
    #položaj prema r4
    x=x+(dt/6)*(vx+2*vx2+2*vx3+vx4)
    y=y+(dt/6)*(vy+2*vy2+2*vy3+vy4)

    
    def graf(self):
        dt=0.01
        while self.y >= 0:      #pomičemo česticu sve dok ne padne na tlo za neki dt
            self.__move(dt)
        while y >= 0:
            self.__R4(dt)
        import matplotlib.pyplot as plt
        plt.xlabel('x/m')
        plt.ylabel('y/m')
        plt.title('Gibanje čestice sa otporom zraka')
        plt.plot(self.x_list, self.y_list)
        return plt.show()
